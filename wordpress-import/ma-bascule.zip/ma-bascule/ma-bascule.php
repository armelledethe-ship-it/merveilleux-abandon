<?php
/**
 * Plugin Name: MA Bascule (temporaire)
 * Description: Passe le site de nouveau.merveilleuxabandon.fr à merveilleuxabandon.fr. À supprimer après usage.
 * Version: 1.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function ma_b_paths() {
	$src  = untrailingslashit( ABSPATH );                 // .../vhosts/nouveau.merveilleuxabandon.fr/htdocs
	$tdir = dirname( dirname( $src ) ) . '/merveilleuxabandon.fr';
	return array( 'src' => $src, 'tdir' => $tdir, 'thtdocs' => $tdir . '/htdocs', 'backup' => $tdir . '/htdocs-ancien-site-2026-10' );
}

function ma_b_replace( $data, $from, $to ) {
	if ( is_string( $data ) ) {
		$u = @unserialize( $data );
		if ( false !== $u || 'b:0;' === $data ) {
			return serialize( ma_b_replace( $u, $from, $to ) );
		}
		return str_replace( $from, $to, $data );
	}
	if ( is_array( $data ) ) {
		foreach ( $data as $k => $v ) { $data[ $k ] = ma_b_replace( $v, $from, $to ); }
		return $data;
	}
	if ( is_object( $data ) && ! ( $data instanceof __PHP_Incomplete_Class ) ) {
		foreach ( get_object_vars( $data ) as $k => $v ) { $data->$k = ma_b_replace( $v, $from, $to ); }
	}
	return $data;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'ma/v1', '/bascule', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function ( WP_REST_Request $r ) {
			global $wpdb;
			$p    = ma_b_paths();
			$step = $r->get_param( 'step' );
			$out  = array( 'paths' => $p );

			if ( 'check' === $step ) {
				$out['src_exists']     = is_dir( $p['src'] );
				$out['thtdocs_exists'] = is_dir( $p['thtdocs'] );
				$out['thtdocs_link']   = is_link( $p['thtdocs'] );
				$out['tdir_writable']  = is_writable( $p['tdir'] );
				$out['backup_exists']  = file_exists( $p['backup'] );
				$out['old_files']      = is_dir( $p['thtdocs'] ) ? array_slice( scandir( $p['thtdocs'] ), 0, 40 ) : null;
				$out['wp_home_const']  = defined( 'WP_HOME' ) ? WP_HOME : null;
				$out['wp_siteurl_const'] = defined( 'WP_SITEURL' ) ? WP_SITEURL : null;
				$out['home']           = get_option( 'home' );
				$out['blog_public']    = get_option( 'blog_public' );
				$auth = get_option( 'auth_settings' );
				$out['authorizer_access'] = is_array( $auth ) ? ( $auth['access_who_view'] ?? null ) : null;
				$out['htaccess']       = file_exists( $p['src'] . '/.htaccess' ) ? file_get_contents( $p['src'] . '/.htaccess' ) : null;
				return $out;
			}

			if ( 'testlink' === $step ) {
				$link = $p['thtdocs'] . '/_ma_test_lien';
				if ( ! file_exists( $link ) ) { $out['symlink'] = @symlink( $p['src'] . '/wp-includes', $link ); }
				$out['exists'] = file_exists( $link . '/version.php' );
				return $out;
			}

			if ( 'untestlink' === $step ) {
				$link = $p['thtdocs'] . '/_ma_test_lien';
				$out['removed'] = is_link( $link ) ? unlink( $link ) : 'absent';
				return $out;
			}

			if ( 'go' === $step ) {
				if ( is_link( $p['thtdocs'] ) ) { return new WP_Error( 'deja', 'Déjà basculé' ); }
				if ( file_exists( $p['backup'] ) ) { return new WP_Error( 'backup', 'Le dossier de sauvegarde existe déjà' ); }
				$t = $p['thtdocs'] . '/_ma_test_lien';
				if ( is_link( $t ) ) { unlink( $t ); }
				if ( ! rename( $p['thtdocs'], $p['backup'] ) ) { return new WP_Error( 'rename', 'Impossible de déplacer l’ancien site' ); }
				if ( ! symlink( $p['src'], $p['thtdocs'] ) ) {
					rename( $p['backup'], $p['thtdocs'] );
					return new WP_Error( 'symlink', 'Lien impossible, ancien site remis en place' );
				}
				$out['moved'] = true;

				$from = array( 'https://nouveau.merveilleuxabandon.fr', 'http://nouveau.merveilleuxabandon.fr', '//nouveau.merveilleuxabandon.fr' );
				$to   = array( 'https://merveilleuxabandon.fr', 'https://merveilleuxabandon.fr', '//merveilleuxabandon.fr' );
				$n = 0;
				foreach ( $wpdb->get_results( "SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_content LIKE '%nouveau.merveilleuxabandon.fr%' OR post_excerpt LIKE '%nouveau.merveilleuxabandon.fr%'" ) as $row ) {
					$wpdb->update( $wpdb->posts, array( 'post_content' => str_replace( $from, $to, $row->post_content ), 'post_excerpt' => str_replace( $from, $to, $row->post_excerpt ) ), array( 'ID' => $row->ID ) );
					$n++;
				}
				$out['posts'] = $n; $n = 0;
				foreach ( $wpdb->get_results( "SELECT meta_id, meta_value FROM {$wpdb->postmeta} WHERE meta_value LIKE '%nouveau.merveilleuxabandon.fr%'" ) as $row ) {
					$wpdb->update( $wpdb->postmeta, array( 'meta_value' => ma_b_replace( $row->meta_value, $from, $to ) ), array( 'meta_id' => $row->meta_id ) );
					$n++;
				}
				$out['postmeta'] = $n; $n = 0;
				foreach ( $wpdb->get_results( "SELECT option_id, option_value FROM {$wpdb->options} WHERE option_value LIKE '%nouveau.merveilleuxabandon.fr%' AND option_name NOT LIKE '\\_transient%'" ) as $row ) {
					$wpdb->update( $wpdb->options, array( 'option_value' => ma_b_replace( $row->option_value, $from, $to ) ), array( 'option_id' => $row->option_id ) );
					$n++;
				}
				$out['options'] = $n;
				update_option( 'blog_public', '1' );
				wp_cache_flush();

				$rules = "# BEGIN MA Redirections\n<IfModule mod_rewrite.c>\nRewriteEngine On\n"
					. "RewriteCond %{HTTP_HOST} ^(www\\.)?nouveau\\.merveilleuxabandon\\.fr$ [NC,OR]\nRewriteCond %{HTTP_HOST} ^www\\.merveilleuxabandon\\.fr$ [NC]\nRewriteRule ^(.*)$ https://merveilleuxabandon.fr/$1 [R=301,L]\n"
					. "RewriteRule ^index\\.html$ / [R=301,L]\n"
					. "RewriteRule ^blog\\.html$ /comprendre/ [R=301,L]\n"
					. "RewriteRule ^visuels\\.html$ /presse/ [R=301,L]\n"
					. "RewriteRule ^extrait\\.html$ /le-livre/ [R=301,L]\n"
					. "RewriteRule ^CP_Merveilleux_abandon\\.pdf$ /wp-content/uploads/2026/10/communique-presse-merveilleux-abandon.pdf [R=301,L]\n"
					. "RewriteRule ^(blessure-abandon-universelle|bebe-interieur-martine|devenir-vraiment-soi|nee-de-deux-meres-filiation)\\.html$ /$1/ [R=301,L]\n"
					. "</IfModule>\n# END MA Redirections\n\n";
				$ht = $p['src'] . '/.htaccess';
				$cur = file_exists( $ht ) ? file_get_contents( $ht ) : '';
				$cur = preg_replace( '/# BEGIN MA Redirections.*?# END MA Redirections\n*/s', '', $cur );
				$out['htaccess'] = false !== file_put_contents( $ht, $rules . $cur );
				return $out;
			}

			if ( 'undo' === $step ) {
				if ( is_link( $p['thtdocs'] ) && file_exists( $p['backup'] ) ) {
					unlink( $p['thtdocs'] );
					$out['restored'] = rename( $p['backup'], $p['thtdocs'] );
				}
				return $out;
			}
			return new WP_Error( 'step', 'Étape inconnue' );
		},
	) );
} );
